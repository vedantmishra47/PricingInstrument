package com.example.sp.service;

import com.example.sp.exception.BatchException;
import com.example.sp.model.BatchJobs;
import com.example.sp.model.PriceRecord;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantReadWriteLock;

@Service
public class PriceServiceImpl implements PriceService {

    private final ConcurrentHashMap<String, PriceRecord> committed = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, BatchJobs> batches = new ConcurrentHashMap<>();

    private final ReentrantReadWriteLock commitLock = new ReentrantReadWriteLock();
    public static final int MAX_CHUNK_SIZE = 1000;
    @Override
    public void startBatch(String batchId) {
        if (batches.putIfAbsent(batchId, new BatchJobs()) != null) {
            throw new BatchException("Batch already started: " + batchId);
        }
    }

    @Override
    public void uploadPrices(String batchId, Collection<PriceRecord> records) {
        final BatchJobs job = batches.get(batchId);
        if (job == null) {
            throw new BatchException("Batch not started: " + batchId);
        }
        if (records == null || records.isEmpty()) {
            return;
        }
        //converting a batch file into smaller chunks of 1000 size
        if (records instanceof List<PriceRecord> list) {
            final int n = list.size();
            final int chunkSize = Math.min(MAX_CHUNK_SIZE, n);
            for (int i = 0; i < n; i += chunkSize) {
                final int to = Math.min(i + chunkSize, n);
                final List<PriceRecord> view = list.subList(i, to);
                //pushing records to temporary concurrentHashMap
                for (PriceRecord r : view) {
                    job.add(r);
                }
            }
        }
    }

    @Override
    public void completeBatch(String batchId) {
        BatchJobs job = batches.remove(batchId);
        if (job == null)
            throw new BatchException("Batch does not exist: " + batchId);

        commitLock.writeLock().lock();//write lock to perform writing one thread at a time, this segment of hashmap wouldn't be available for read
        try {
            //publish records in permanent concurrentHashMap, visible to consumers
            for (PriceRecord r : job.getAll().values()) {
                committed.merge(
                        r.getId(),
                        r,
                        (oldV, newV) -> newV.getAsOf().isAfter(oldV.getAsOf()) ? newV : oldV
                );
            }
        } finally {
            commitLock.writeLock().unlock();
        }
    }

    @Override
    public void cancelBatch(String batchId) {
        batches.remove(batchId); // discard temp data
    }

    @Override
    public Map<String, PriceRecord> getLatestPrices(Collection<String> ids) {
        commitLock.readLock().lock();//read lock to perform reads from multiple threads, at this moment no write operation will be possible
        try {
            Map<String, PriceRecord> result = new HashMap<>();
            for (String id : ids) {
                PriceRecord r = committed.get(id);
                if (r != null) result.put(id, r);
            }
            return result;
        } finally {
            commitLock.readLock().unlock();
        }
    }
}
